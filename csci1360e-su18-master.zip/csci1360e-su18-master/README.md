# CSCI 1360E: Foundations for Informatics and Analytics

[![Binder](https://mybinder.org/badge.svg)](https://mybinder.org/v2/gh/eds-uga/csci1360e-su18/master)

...aka, Introduction to Data Science. Summer 2018 rendition of CSCI 1360(E).

All course materials will be posted in this space.
